package com.capgemini.labassignments.lab2;

public class Lab2b {
	 int n;
		public  void check(){
		if(n>0)
		{
			System.out.println("positive number");
		}
		else
		{
			System.out.println("negative no");
		}

	}
}
		class Main {
		
	public static void main(String[] args) {
		Lab2b obj= new Lab2b();
		int N= Integer.parseInt(args[0]);
		obj.n=N;
		obj.check();
}
		}
