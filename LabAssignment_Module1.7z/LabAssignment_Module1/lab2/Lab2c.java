package com.capgemini.labassignments.lab2;

 class Person {
	private String first_name, last_name, gender;
	Person()
	{
		System.out.println("default constroctor");
	}
	Person(String fname, String lname, String gen)
	{
		first_name=fname;
		last_name=lname;
		gender=gen;
	}
	public void setfirstname(String fname)
	{
		first_name=fname;
	}
	public String getfirstname()
	{
		return first_name;
	}
	public void setlastname(String lname)
	{
		last_name=lname;
	}
	public String getlastname()
	{
		return last_name;
	}
	public void setgender(String gen)
	{
		gender=gen;
	}
	public String getgender()
	{
		return gender;
	}
	}

public class Lab2c {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person obj=new Person("Divya","Bharathi","F");
		System.out.println("first name :"+obj.getfirstname());
		System.out.println("last name :"+obj.getlastname());
		System.out.println("gender :"+obj.getgender());
		obj.setfirstname("Abhinav");
		obj.setlastname("Bhadauria");
		obj.setgender("Male");
		System.out.println("first name :"+obj.getfirstname());
		System.out.println("last name :"+obj.getlastname());
		System.out.println("gender :"+obj.getgender());
	}
}