package com.capgemini.labassignments.lab2;

 class Person2 {
	private String first_name, last_name;
	private Gender gender;
	Person2()
	{
		System.out.println("default constroctor");
	}
	Person2(String fname, String lname, Gender gender)
	{
		first_name=fname;
		last_name=lname;
		this.gender=gender;
		
	}
	public Gender getGender() {
		return gender;
		}
	public void setGender(Gender gender) {
		this.gender = gender;
		}
	public void setfirstname(String fname)
	{
		first_name=fname;
	}
	public String getfirstname()
	{
		return first_name;
	}
	public void setlastname(String lname)
	{
		last_name=lname;
	}
	public String getlastname()
	{
		return last_name;
	}
	
}

enum Gender
{
	M,F;
}
public class Lab2e {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person2 obj=new Person2("Divya","Bharathi",Gender.F);
		System.out.println("first name :"+obj.getfirstname());
		System.out.println("last name :"+obj.getlastname());
		System.out.println("gender :"+obj.getGender());
		obj.setfirstname("abc");
		obj.setlastname("xyz");
		obj.setGender(Gender.M);
		System.out.println("first name :"+obj.getfirstname());
		System.out.println("last name :"+obj.getlastname());
		System.out.println("gender :"+obj.getGender());
	}

}

