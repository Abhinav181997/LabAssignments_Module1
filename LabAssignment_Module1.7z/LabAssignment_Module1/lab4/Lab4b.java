package com.capgemini.labassignment.lab4;

class Saving extends Account1 {
	final int minimumbalance=1000;
	 Saving(int balance)
	{
		super(balance);
	}
	public boolean withdraw(int balance)
	{
		if(super.balance>minimumbalance)
		{
			System.out.println("withdraw possible");
			super.balance-=balance;
			return true;
		}
		return false;
	}
}

class Current extends Account1{
	int overdraftlimit=2000;
	public Current(int balance)
	{
		super(balance);
	}
	public boolean withdraw(int limit)
	{
		if(limit<overdraftlimit)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}

class Account1 {
	int balance;
	public Account1(int balance)
	{
		this.balance=balance;
	}
	public boolean withdraw(int balance)
	{
		return true;
	}
}

public class Lab4b {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Saving s=new Saving(10000);
		Current c=new Current(5000);
		s.withdraw(2000);
		c.withdraw(2000);
}
}
