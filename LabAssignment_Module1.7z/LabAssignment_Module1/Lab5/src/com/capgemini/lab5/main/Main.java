package com.capgemini.lab5.main;

public class Main {

}
