package com.capgemini.lab6.problem3.exception;

public class EmployeeException extends Exception{

}
