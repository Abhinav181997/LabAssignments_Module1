package com.capgemini.lab9.exception;

public class EmployeeException extends Exception{

}
