package com.capgemini.lab11_2;
@FunctionalInterface
public interface IStringSpace {
	public void space(String c);
	

}
