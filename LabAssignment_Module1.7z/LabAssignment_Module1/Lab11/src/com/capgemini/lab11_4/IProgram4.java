package com.capgemini.lab11_4;
@FunctionalInterface
public interface IProgram4 {
	public simple methodDemo();


}
