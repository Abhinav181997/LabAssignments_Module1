package com.capgemini.lab11_3;

public interface ILoginOperation {
boolean login(String uname, String pass);

}
