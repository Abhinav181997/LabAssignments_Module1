package com.capgemini.lab11_5;

public interface IFactorial {
  public void fact();
}
