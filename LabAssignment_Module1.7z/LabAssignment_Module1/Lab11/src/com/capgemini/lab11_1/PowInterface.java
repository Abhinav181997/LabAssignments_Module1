package com.capgemini.lab11_1;

public interface PowInterface {
public double power(double x,double y);
	
}
