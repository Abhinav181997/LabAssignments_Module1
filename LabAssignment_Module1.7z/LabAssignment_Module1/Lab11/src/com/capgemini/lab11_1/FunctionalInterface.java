package com.capgemini.lab11_1;

public @interface FunctionalInterface {

}
